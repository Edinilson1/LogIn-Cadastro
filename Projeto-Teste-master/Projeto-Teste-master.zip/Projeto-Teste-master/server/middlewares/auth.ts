import { Request, Response, NextFunction } from "jsonwebtoken";


const auth = (req: Request, res:Response, next:NextFunction) => {

    // Fazer verificação de token
    
}

export default auth;